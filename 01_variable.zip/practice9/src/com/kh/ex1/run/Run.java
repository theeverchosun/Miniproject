package com.kh.ex1.run;

import com.kh.ex1.model.vo.Audio;
import com.kh.ex1.model.vo.RemoteControl;
import com.kh.ex1.model.vo.Television;

public class Run {

	public static void main(String[] args) {
		
		/*RemoteControl rc = new Television();
		RemoteControl rc2 = new Audio();
		
		rc.turnOn();
		rc.setVolume(7);
		rc.turnoff();
		
		rc2.turnOn();
		rc2.setVolume(5);
		rc2.turnoff();
		*/
		
		
		RemoteControl[] arr = new RemoteControl[2];
		arr[0] = new Television();
	    arr[1] = new Audio();
	    
	    for(RemoteControl tr: arr) {
	    	
	    	tr.turnOn();
	    	
	    	if (tr instanceof Television) {
	    		tr.setVolume(7);
	    		
	    	}else if (tr instanceof Audio) {
	    		tr.setVolume(5);
	    	}
	    	tr.turnoff();
	    	
	    	
	    }
	
		}

	}


