package com.kh.ex2;

public class Rectangle implements Shape {
	
	double RR;
    double PR;
	
	public Rectangle(int RR, int PR) {
		
		this.RR = RR;
		this.PR = PR;
	}

	@Override
	public double caculateArea() {
		
		return RR*PR;
	}

}
