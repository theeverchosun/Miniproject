package FModel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;


public class View {
	
	private Model[] memberArray;
    private int memberCount;
    private Scanner sc;
    private final String FILE_PATH = "memberList.txt"; // 저장될 파일 이름

    // 생성자
    public View(int capacity) {
        this.memberArray = new Model[capacity];
        this.memberCount = 0;
        this.sc = new Scanner(System.in);
        
        // 1. 프로그램이 켜질 때 안전하게 파일부터 읽어옵니다.
        loadFromFile();
    }

    // 메인 메뉴 화면
    public void mainMenu() {
        while (true) {
            System.out.println("\n===== 헬스장 회원 관리 프로그램 =====");
            System.out.println("1. 회원 추가");
            System.out.println("2. 회원 목록");
            System.out.println("3. 특별관리 대상");
            System.out.println("0. 프로그램 종료");
            System.out.print("👉 메뉴 번호를 선택하세요: ");
            
            int menu = -1;
            try {
                menu = sc.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("❌ 숫자로만 입력해주세요.");
                sc.nextLine(); // 버퍼 쓰레기 청소
                continue;
            }

            switch (menu) {
                case 1:
                    addNewMemberMenu();
                    break;
                case 2:
                    printAllMembers();
                    break;
                case 3:
                    printSpecialCareMembers();
                    break;
                case 0:
                    System.out.println("프로그램을 종료합니다.");
                    saveToFile(); // 2. 프로그램 종료 시 최종 저장
                    return; 
                default:
                    System.out.println("❌ 없는 메뉴 번호입니다. 다시 선택해주세요.");
            }
        }
    }

    // 1번 메뉴: 회원 추가 입력창
    private void addNewMemberMenu() {
        if (memberCount >= memberArray.length) {
            System.out.println("⚠️ 헬스장 정원이 가득 찼습니다. 더 이상 추가할 수 없습니다.");
            return;
        }

        System.out.println("\n--- [ 1. 회원 추가 모드 ] ---");
        System.out.print("이름을 입력하세요: ");
        String name = sc.next();

        String gender = "";
        while (true) {
            System.out.print("성별을 입력하세요 (남/여): ");
            gender = sc.next();
            if (gender.equals("남") || gender.equals("여") || gender.equals("남자") || gender.equals("여자")) {
                break;
            } else {
                System.out.println("❌ '남' 또는 '여'로 입력해주세요.");
            }
        }

        int age = 0;
        double height = 0;
        double weight = 0;

        while (true) {
            try {
                System.out.print("나이를 입력하세요: ");
                age = sc.nextInt();

                System.out.print("키를 입력하세요 (cm 또는 m): ");
                height = sc.nextDouble();
                if (height >= 100.0) {
                    height = height / 100.0; // cm 자동 변환
                }

                System.out.print("몸무게를 입력하세요 (kg): ");
                weight = sc.nextDouble();

                if (age <= 0 || height <= 0 || weight <= 0) {
                    System.out.println("❌ 0보다 큰 숫자를 입력해야 합니다. 다시 입력하세요.");
                    continue;
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("❌ 나이, 키, 몸무게는 숫자로만 입력해야 합니다.");
                sc.nextLine(); // 버퍼 쓰레기 청소
            }
        }

        Model member = new Model(name, gender, age, height, weight);
        addMember(member);
        
        // 추가할 때마다 파일에 실시간 반영해두면 안전합니다.
        saveToFile(); 
    }

    // 배열 등록 핵심 로직
    public void addMember(Model member) {
        memberArray[memberCount] = member;
        memberCount++;
        System.out.println("✅ " + member.getName() + " 회원이 성공적으로 등록되었습니다.");
    }

    // 2번 메뉴: 전체 회원 리스트 출력
    public void printAllMembers() {
        System.out.println("\n=============================================");
        System.out.println("📋  [전체 회원 목록 (현재 " + memberCount + "명)]");
        System.out.println("=============================================");
        
        if (memberCount == 0) {
            System.out.println("등록된 회원이 없습니다.");
        } else {
            for (int i = 0; i < memberCount; i++) {
                Model m = memberArray[i];
                if (m != null) {
                    System.out.printf("%d. 이름: %s | 성별: %s | 나이: %d세 | 키: %.1fcm | 몸무게: %.1fkg (BMI: %.2f)\n", 
                            (i + 1), m.getName(), m.getGender(), m.getAge(), (m.getHeight() * 100), m.getWeight(), m.calculateBMI());
                }
            }
        }
        System.out.println("=============================================");
    }

    // 3번 메뉴: 특별 관리 대상자 명단 출력
    public void printSpecialCareMembers() {
        System.out.println("\n=============================================");
        System.out.println("⚠️  [BMI 특별 관리 대상자 명단]");
        System.out.println("=============================================");
        
        int count = 0;
        for (int i = 0; i < memberCount; i++) {
            Model member = memberArray[i];
            if (member != null && member.isRequiresSpecialCare()) {
                System.out.printf("- 이름: %s | 성별: %s | BMI: %.2f\n", 
                        member.getName(), member.getGender(), member.calculateBMI());
                count++;
            }
        }
        if (count == 0) {
            System.out.println("특별 관리 대상 회원이 없습니다.");
        }
        System.out.println("=============================================");
    }

    // 💾 파일 저장 핵심 기능
    public void saveToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (int i = 0; i < memberCount; i++) {
                Model m = memberArray[i];
                if (m != null) {
                    bw.write(String.format("%s,%s,%d,%.2f,%.2f\n", 
                            m.getName(), m.getGender(), m.getAge(), m.getHeight(), m.getWeight()));
                }
            }
            System.out.println("💾 회원 정보가 파일(" + FILE_PATH + ")에 업데이트 되었습니다.");
        } catch (IOException e) {
            System.out.println("❌ 파일 저장 중 오류 발생: " + e.getMessage());
        }
    }

    // 📂 파일 로드 핵심 기능
    public void loadFromFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            System.out.println("📂 기존 회원 정보를 파일에서 불러오는 중...");
            
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue; // 빈 줄 패스

                String[] data = line.split(",");
                if (data.length < 5) continue; // 데이터 깨짐 패스
                
                String name = data[0].trim();
                String gender = data[1].trim();
                int age = Integer.parseInt(data[2].trim()); 
                double height = Double.parseDouble(data[3].trim());
                double weight = Double.parseDouble(data[4].trim());

                Model member = new Model(name, gender, age, height, weight);
                
                if (memberCount < memberArray.length) {
                    memberArray[memberCount] = member;
                    memberCount++;
                }
            }
            System.out.println("✅ 불러오기 완료! (현재 등록된 회원: " + memberCount + "명)");
        } catch (IOException e) {
            System.out.println("ℹ️ 저장된 회원 정보 파일이 없습니다. 새로 시작합니다.");
        } catch (Exception e) {
            System.out.println("⚠️ 파일 데이터 복원 중 문제가 발생해 일부만 로드했습니다.");
        }
    }
}
