package com.kh.ex3;

import java.util.Scanner;

public class Main {
	public static void Main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		char a;
		
		System.out.print("입력 : ");
		
		String b = sc.next();
		int f = 1022;
		a = 'p';
		
		
		
		System.out.println(a);
	
		
		
	}

}
