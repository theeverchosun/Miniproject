package com.kh.ex1.model.vo;

public interface RemoteControl {
	
	public void turnOn();
	
	public void turnoff();
	
	public void setVolume(int volume);

}
