package com.kh.ex2.controller;

import java.time.LocalDateTime;

public class Customer {
	
	

	private String id;
	private int remainingTime;
	private boolean isCheckdln;
	private LocalDateTime checklnTime;
	
	public Customer(String id) {
		super();
		this.id = id;
		this.remainingTime = 30;
		this.isCheckdln = false;
		this.checklnTime 
	}

	/**
	 * @return the remainingTime
	 */
	public int getRemainingTime() {
		return remainingTime;
	}

	/**
	 * @param remainingTime the remainingTime to set
	 */
	public void setRemainingTime(int remainingTime) {
		this.remainingTime = remainingTime;
	}

	/**
	 * @return the isCheckdln
	 */
	public boolean isCheckdln() {
		return isCheckdln;
	}

	/**
	 * @param isCheckdln the isCheckdln to set
	 */
	public void setCheckdln(boolean isCheckdln) {
		this.isCheckdln = isCheckdln;
	}

	/**
	 * @return the checklnTime
	 */
	public LocalDateTime getChecklnTime() {
		return checklnTime;
	}

	/**
	 * @param checklnTime the checklnTime to set
	 */
	public void setChecklnTime(LocalDateTime checklnTime) {
		this.checklnTime = checklnTime;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", remainingTime=" + remainingTime + ", isCheckdln=" + isCheckdln
				+ ", checklnTime=" + checklnTime + "]";
	}

}
