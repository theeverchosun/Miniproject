package com.kh;

import java.util.Scanner;

public class c_logical {
	
	/*
	 * 논리 연산자 (이항연산자)
	 * 두개의 논리값을 연산(true/false)
	 * 결과값은 논리값
	 * 종류 : && ||
	 * 
	 * - A && : A, B 모두 true 일 때만 true
	 *   true && true => true
	 *   true && false =>false
	 *   flase && true => false
	 *   false && false => false
	 *   
	 *    A || B : A또는 B둘중 하나만 true 면 true
	 *    true || true => true
	 *    true || false => true
	 *    false || true => true
	 *    false || fasle => false
	 *    
	 *    SCE(단축평가)
	 *    && 연산자가 앞이 false면 뒤에는 실행되지않는다
	 *    || 연산자가 앞이 true이면 뒤에는 실행되지않는다
	 */

	public static void main(String[] args) {
		method2();
		
		

	}
	public static void method1() {
		// 입력받은값이 1~ 10사이의 값인확인
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수를 입력하세요 : ");
		int num = sc.nextInt();

		System.out.println("입력된 값은 1~10 사이의 값인가?"+( num >=1 && num <= 10));
		
		System.out.println("입력된 값은 1~10 벗어나는가?"+(num<1 || num>10));
	}
	
	public static void method2() {
		Scanner sc = new Scanner(System.in);
		//입력받은 문자가 소문자인가
		//'a':97 z:122
		System.out.print(" 입력");
	String B = sc.nextLine();
	
	char A = B.charAt(0);
	
	boolean result = A >= 97 && A <= 127;
	boolean result2 = A >= 'a' && A <='z';
			
	System.out.print(result2);
		
		
		
		
	}

}
