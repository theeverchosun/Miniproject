package com.kh.pos.view;
import java.util.Scanner;

import com.kh.pos.controller.PosController;
import com.kh.pos.model.Customer;
import com.kh.pos.model.PaymentMethod;

public class Posmenu {
	
	private PosController pc = new PosController();
	private Scanner sc = new Scanner(System.in);
	
	public void mainMenu() {
		
		System.out.println("자가 쇼핑 pos 등록");
		System.out.print("고객 이름 입력");
		String name = sc.next();
		System.out.print("고객나이입력:");
		int age = sc.nextInt();
		pc.insertCustomer(new Customer(name,age));
		sc.nextLine();
		
		while(true) {
			System.out.println("====스마트폰 단만길 메뉴 =====");
			System.out.println("1 마이페이지");
			System.out.println("2. 전체 사용가능 결제수단 조회");
			System.out.println("3. 결제수단 조회");
			System.out.println("4. 결제하기");
			System.out.println("9. 시스템 종료");
			System.out.println("메뉴 입력 :");
			
			int menu = sc.nextInt();
			switch(menu) {
			case 1 :
				//고객정보는 controller의 getcustomerinfo통해 변화
				Customer custom = pc.getCustomerInfo();
				
				//System.out.println(custom.toString());
				System.out.println(custom);
				
				break;
				
			case 2 :
				PaymentMethod[] methods = pc.selectAllmethod();
				for(int i =0; i<methods.length; i++) {
					System.out.println("["+i+"번]"+ methods[i]);
				}
				break;
				
			case 3 :
			    searchMethod();
				break;
			case 4 :
			   checkout();
			    break;
			 
			case 9 :
				
				//break;
				return;
				
				default :
					 System.out.println("알수없음");
					 break;
			}
			
			
		}
		
	}
	
	public void printAllMethod() {
		
	}
	public void searchMethod() {
		System.out.print("검색할수단 입력");
		String keyword = sc.nextLine();
		
		PaymentMethod[] result = pc.searchMethod(keyword);
		
		for(PaymentMethod method :result) {
			if(method != null) {
				System.out.println(method);
			}
		}
		
	}
	public void checkout() {
		System.out.print("이용할 결제 수단 번호 선택 :");
		int index = sc.nextInt();
		
		int result = pc.processPayment(index);
		
		if (result==0) {
			System.out.println("결과 결제 성공");
		}else if(result==1) {
			System.out.println("결과  제한연령미달이거나 모바일 가이드 (제한나이+3세) 기준미달로 승인이거절됩니다.");
			
		}else if (result==2) {
			System.out.println("결과 결제성공 캐시백 제휴카드로 확인되어 멤버십  포인트 500점 특별 적립되었습니다");
			
		}else {
			System.out.println("시스템 오류 관리자에게 문의하세요");
		}
		
	}

}
