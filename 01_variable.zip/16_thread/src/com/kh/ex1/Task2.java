package com.kh.ex1;

public class Task2 extends Thread {

	@Override
	public void run() {
	//스레드를 통해 실행할 내용
		
		String threadName = Thread.currentThread().getName();
	
		System.out.println("Thread1 실행중");
	}

}
