package com.kh.stock.model;

public class SmartPhone extends Device {

	private String os;
	
	public SmartPhone() {
		
	}
	
	public SmartPhone(String brand, String name, int price, String os) {
		super(brand, name, price);
		this.os = os;
		
	}

	@Override
	public String getInoformation() {
		// TODO Auto-generated method stub
		return super.getInoformation() + "Os =" + os;
	}

		

	
}
