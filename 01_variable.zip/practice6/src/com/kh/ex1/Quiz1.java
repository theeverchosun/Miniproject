package com.kh.ex1;

import java.util.Scanner;

public class Quiz1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int arr [][];
		int A = 0;
		
		
		arr = new int [5][1];
		
		for (int r = 0; r < arr.length; r++) {
            System.out.print((r + 1) + "번 학생 점수 입력 : ");
            arr[r][0] = sc.nextInt(); 
        }
		for (int r = 0; r < arr.length; r++) {
            for (int i = 0; i < arr[r].length; i++) {
                A += arr[r][i]; 
            }
        }
        
		double avg = (double)A/ arr.length;
        // 결과 출력
        System.out.println("====================");
        System.out.println(" 총합 : " + A);
        System.out.println(" 평균 : " +avg);
        
        sc.close();
    }
			
			 

}


		
		
		
    
		
       
		
		
		
	


