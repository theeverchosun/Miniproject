package com.kh;

import java.util.Scanner;

public class D_thripe {

	public static void main(String[] args) {
		method2();
		/*
		 * 삼항연산자 (항이 3개인 연산자)
		 * 조건식 + 조건식이 true일때 + 조건식이 false일때
		 */
		

	}
	
	public static void method1() {
		// 입력한값이  x인경우 "종료합니다" 출력 그렇지않으면 "계속진행합니다"
		Scanner sc = new Scanner(System.in);
		System.out.print("입력:");
		String str = sc.nextLine();
		
		char A = str.charAt(0);
		
		String rs = (A =='x' || A == 'X') ? "종료합니다" : "계속진행합니다";
		System.out.println(rs);
		
	}
	
	public static void method2() {
		/*
		 * 사용자에게 두 개의 정수와 + 또는 -를 입력받아 연산결과를 출력
		 * 단 + 또는 -외의 문자가 입력되었을 경우 입력이 잘못되었습니다 출력
		 * 입력예시 10 20 +
		 * 출력예시 10 + 20 = 30
		 * 
		 * 입력예시 5 10 = 입력이 잘못되었습니다
		 * 
		 */
		Scanner sc = new Scanner(System.in);
		System.out.print("입력");
		System.out.print("결과확인");
		System.out.print(":");
		
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		String st1 = sc.next();
		char op = st1.charAt(0);
		
		String rs1 = ""+((op == '+') ? n1 + n2 :(op == '-') ? n1 - n2 : ("입력이잘못되었습니다"));
	
		System.out.printf("%d %c %d = %s\n", n1, op, n2, rs1);
		
	}

}
