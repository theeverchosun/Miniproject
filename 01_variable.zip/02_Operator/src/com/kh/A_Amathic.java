package com.kh;

public class A_Amathic {

	public static void main(String[] args) {
		
		mehto2();
		/*산술연산자(이항연산자) = > + -/ % *
		 * 
		 * 우선 순위  : /  * % > + -
		 */

	}
	
	public static void metho1() {
		
		// 10, 3 값을 각각 1n 2n에 지정
		
		int n1 =10; int n2 = 3;
		
		//n1 n2의합 차 곱 몫 나머지 출력
		
		System.out.println("n1 + n2="+ (n1 + n2));
		System.out.println("n1 - n2 ="+ (n1 - n2));
		System.out.println("n1 X n2="+ (n1 * n2));
		System.out.println("n1 % n2 ="+(n1 % n2));
		System.out.println("n1 / n2="+(n1 / n2));

		
	}
	
	public static void mehto2() {
		int a = 5; int b = 10;
		
		int c = ++a + b; //c=>
		int d = c / a;
		int e = c % a;
		int f = e++;
		int g = --b + d--;
		int h = 2;
		int i = a++ + b / (--c / f) * (g-- - d) % (++e + h);
		
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		System.out.println(g);
		System.out.println(h);
		System.out.println(i);
		
		
		
		
	}

}
