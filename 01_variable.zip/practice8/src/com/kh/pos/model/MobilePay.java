package com.kh.pos.model;

public class MobilePay extends PaymentMethod {
	
	private String payVendor;
	
	public MobilePay() {
		
	}

	public MobilePay(String name, int minAge, int transactionLimit, String payVendor) {
		super(name, minAge, transactionLimit);
		this.payVendor = payVendor;
	}
	public String toString() {
		return String.format("모바일페이 - 플랫폼 : %s | 제공사: %s",
				super.toString(),payVendor);
	}
}
