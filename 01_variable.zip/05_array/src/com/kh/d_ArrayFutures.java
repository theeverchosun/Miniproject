package com.kh;

public class d_ArrayFutures {

	public static void main(String[] args) {
		method1();
		/*
		 * 변수종류
		 * 일반변수(기본자료형)
		 * 실제데이터(리터럴)를 메모리에 바로 저장하는 변수
		 * stack에 저장
		 * 기본자료형 :byte char boolean long int float double short
		 * 참조 변수 
		 * 실제데이터는 heap에 저장하고 그곳의 주소값을 저장하는 변수
		 * 
		 * 배열 특징
		 * -생성한후 직접 값을 초기화하지않아도  기본값으로 초기화된다
		 * -heap이라는 영역은 빈공간으로 존재할수없어서
		 * 공간이 만들어질때 jvm에 의해 기본값으로 초기화됨
		 * 
		 * 단점 :한번 생성한후 배열크기를 변경할수없다
		 * 크기변경하라면  새로 생성해야된다
		 */
		
		

	}

	public static void method1() {
		//정수형 배열 iArr선언하고 크기ㅏ 10인 배열생성(할당)
		
		int[] iArr = new int[10];
		//실수형 배열 dArr을 선언하고 크기가 4인배열
		
		double[] dArr =new double[4];
		// = > 배열을 생성까지만 한 상태
		
		char[] cArr = new char[3];
		//*iArr 배열값들을 출력
		
		System.out.println(cArr);
		
		
		for(int i =0; i < iArr.length; i++) {
			System.out.println(iArr[i]);
		}
		
		for(int j =0; j < dArr.length; j++) {
			
			System.out.println(dArr[j]+" ");
		}
		System.out.println();
		
		System.out.println(iArr);
		System.out.println(dArr);
		//배열의 자료형 + @ + 주소값(16진수)
		
		int[] arr = null;
		
		//System.out.println(arr[0]);
		// 실제데이터가 가 없는 첫번째칸에 접근하려할때 오류발생
		
		arr = new int[5];
		System.out.println(arr[4]);
		//System.out.println(arr[5]); 인덱스를 범위를 벗어낫기에 오류
		
		//재할당 -->배열을 새로 생성해서 할당
		System.out.println("할당전"+arr);
		arr = new int[7];
		System.out.println("할당후"+arr);
		
		
		
	}
	
}
