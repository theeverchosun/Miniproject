package com.kh.run;
import com.kh.menu.Drink;
import com.kh.menu.Americano;
import com.kh.menu.Latte;

public class Run {

	public static void main(String[] args) {
		
		
		Drink[] menu = new Drink[2];
		
		
		menu[0] = new Americano("아메리카노",2000);
		menu[1] = new Latte("라떼",3000);
		
		for(int i=0; i<menu.length; i++) {
			
			String name = menu[i].getName();
			int price = menu[i].getPrice();
			
			System.out.printf("[%s] 가격 : [%d]\n", name, price);
			menu[i].order();
		}
		
		
		
	}

}
