package com.kh.pos.model;

public class PaymentMethod {
	
	protected String name;
	protected int minAge;
	protected int transactionLimit;
	
	public PaymentMethod() {
		
	}

	public PaymentMethod(String name, int minAge, int transactionLimit) {
	
		this.name = name;
		this.minAge = minAge;
		this.transactionLimit = transactionLimit;
	}
	
	public String getName() {
		 return name;
	}
	
	public int getMinAge() {
		return minAge;
	}
	//[2번] 신용/체크카드 - 카드명: 국민 나라사랑카드, 제한연령: 12세, 한도: 500000원 | 캐시백 여부: 캐시백 가능

	public String toString( ) {
		//return "카드명:"+name+"제한연령:"+minAge+"한도"+transactionLimit;
		
		return String.format("%s, 제한연령: %d, 한도 %d원",
				                   name, minAge,transactionLimit);
	}
	

}
