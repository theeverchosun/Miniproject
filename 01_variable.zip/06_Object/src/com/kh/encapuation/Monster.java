package com.kh.encapuation;

public class Monster {
	
	// --- 필드 ---
	private int hp;//체력
// 생성자
	//기본생성자
	public Monster() {
		//체력을 100으로 초기화
		
		this.hp = 100;
	}
	//메소드 
	//공격당함 => 체력을 깍는 메소드 (hp의 변수를 감소)
	
	// 체력 확인 => 체력값을 확인하는 메소드 (hp변수의 값을 반환)
	
	public int gethp() {
		return this.hp;
	}

	
	public void att(int dmg) {
		
		this.hp = this.hp - dmg;
		
	}
}
