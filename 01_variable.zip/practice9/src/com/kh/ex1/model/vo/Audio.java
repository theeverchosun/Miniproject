package com.kh.ex1.model.vo;

public class Audio implements RemoteControl {
	
	private int volume;
	
	public Audio() {
		
	}

	public Audio(int volume) {
		super();
		this.volume = volume;
	}

	@Override
	public void turnOn() {
		System.out.println("Audio를 켭니다.");
		
	}

	@Override
	public void turnoff() {
		System.out.println("Audio를 끕니다.");
		
	}

	@Override
	public void setVolume(int volume) {
		if (volume >=0 && volume <=10) {
			this.volume =volume;
			System.out.println("Audio 볼률을"+ volume+"조절합니다");
		}else {
			System.out.println("Audio 볼륨 범위에 해당하지 않습니다");
		}
		
	}
	
	
	
	

}
