package com.kh;

import java.util.Scanner;

public class ff {

	public static void main(String[] args) {
		method1();
		
		/*기본적으로 프로그램은 순차적으로 실행 (위 -> 아래, 왼쪽 ->오른쪽)
		 * 순차적인 흐름을 바꿀 때 "제어문을" 사용해 처리가능
		 * 
		 * 조건문if 
		 * 
		 * 1.단독 if문
		 * 
		 * if (조건식) {
		 *            조건식의 결과가 true일때 사용할내용}
		 *  2. if else 문
		 *  
		 *  if (조건식)  {
		 *  } else { 조건의 결과가 false 일때 실행할 내용
		 *  }
		 *  
		 *  3 if ~else if ~else 문
		 *  if (조건식) {
		 *  } else if(조건식2) { 조건식1이 false 조건식 2가 true일때
		 *  } else{ 조건식 1,2가 모두 false일때 실행할 내용}
		 *  
		 */
		
	}
	
	public static void method1(){
		
		Scanner sc = new Scanner(System.in);
		
		//입력할값이 1~10사이일때 값을 출력 그렇지 않으면 벗어났습니다
		System.out.print("입력 : ");
		int A = sc.nextInt();
		
		if(A<=10 && A>=1) {
			System.out.println(A);
		} else { System.out.println("벗어났습니다");}
		sc.close();
	}
		
		public static void mehtod2() {
			
			
			
		}

}

