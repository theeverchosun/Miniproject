package com.kh;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class F_DateTime {

	public static void main(String[] args) {

		test1();

		//test2();
		
		

	}

	public static void test1() {
		//1 날짜만 관리
		LocalDate today = LocalDate.now();
		System.out.println(today);
		
		// 특정일에 대한 데이터로 생성 : LocalDate.of(연도,월,일)
		LocalDate date1 = LocalDate.of(2026, 6, 11);
		System.out.println(date1);
		//Date와 달리 연도와 월에 대해 별도의 계산이 필요 없음
		// LocalTime 시간만 관리
		
	 LocalTime now = LocalTime.now();
	 System.out.println(now);
	 
	 // DateTimeFormatter : 형식지정클래스
	 String pattern = "yyyy년 MM월 dd일";
	 DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
	 System.out.println(formatter);
		
	 //날짜객체.format(형식지정객체)
	 System.out.println( today.format(formatter));
	 System.out.println( date1.format(formatter));
	}
	
	public static void test2() {
		
		
	
				//LocalDateTime : 날짜와 시간 통합관리
		LocalDateTime today = LocalDateTime.now();
		System.out.println(today);
		//* 월 정보 반환 .getMoth(), getMothValue()
		
		System.out.println(today.getMonth());
		System.out.println(today.getMonthValue());
		//*일정보반환 :getDayofMonth(), getDayofYear()
		System.out.println(today.getDayOfMonth());
		System.out.println(today.getDayOfYear());
		//올해는 몇일 남았는지 ?
		// -> 윤년 today.toLocalDate().isLeapYear	()
		
		int totalDays =	 today.toLocalDate().isLeapYear() ? 366 : 365;
		System.out.println("올해남은일수..."+(totalDays - today.getDayOfYear()));
		
		System.out.println(today.getHour());//24시간제로 계산
		
		//퇴근 시간까지 얼마나 남았지? 18 -현재시간
		int remindTime = 18 - today.getHour();
		if(remindTime>0) {
			System.out.println("집가는시간은?"+remindTime );
		}else {
			System.out.println("퇴근");
		}
		System.out.println(18-today.getHour());
		String pattern = "yyyy년 MM월 dd일";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		System.out.println(today.format(formatter));
		
		
		
		
		
		
	}
	
	
	
}
