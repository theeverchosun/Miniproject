package com.kh;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.kh.model.Person;

public class C_filestream {

	public static void main(String[] args) {
		objectRead();

	}
	
	

	// 파일 출력: 프로그램 파일 --- > 파일
	
   public static void fileSave() {
	   BufferedWriter bw = null;
	   /*
	    * 기반스트림 : FileWriter. 파일을 직접적으로 연결하여 2바이트씩 출력하는 스트림
	    * 보조스트림 : BufferedWriter.
	    * 
	    */
	   try {
	   System.out.println("*****fileSaver******");
	   
	   // 1.기반스트림 생성
	   FileWriter fw = new FileWriter("file1.txt");
	   
	   // 2. 보조 스트림 생성
	   bw = new BufferedWriter(fw);
	   bw.write("파일에 데이터쓰기!!");
	   bw.write("재밋다");
	   
	   bw.newLine();
	   
	   bw.flush();
	   
	   bw.close();
	   
	   
	   
   } catch (IOException e) {
	   e.printStackTrace();
   } finally {
	  try { 
		  if(bw!=null) {
			   bw.close(); 
		  }
		 
	  }catch (IOException e) {
		  e.printStackTrace();
	  }
	 
   }
	
	
}
public static void fileread() {
		// 기반 스트림 FileReader
		// 보조 스트림 BufferedReader 한줄씩 데이터를 읽어오도록 도와줌
		System.out.println ("***file reader***");
		
		try(FileReader fr = new FileReader("file1.txt");
				BufferedReader br = new BufferedReader(fr)) {
					System.out.println(br.readLine());
				
		
		
	}catch  (IOException e) {
		 e.printStackTrace();
	}
   
}

public static void objectsave() {
	//객체 데이터 생성
	Person p1 = new Person("홍길동", 20, 178.5);
	Person p2 = new Person("강감찬", 58, 165.4);
	Person p3 = new Person("이도", 22, 195.4);
	
	// 보조스트림 ObjectOutputStream 객체단위로 출력을 도와주는 스트림
	// 기반스트림 FileOutputStream 1바이트 단위로 파일에 출력하는 스트림
	
	try(ObjectOutputStream oos = new ObjectOutputStream(
			new FileOutputStream("file2.txt"))
			){
		oos.writeObject(p1);
		oos.writeObject(p2);
		oos.writeObject(p3);
	}catch (IOException e) {
		  e.printStackTrace();
	  }
	
	
}

public static void objectRead() {
	//* 보조스트림 :ObjectInputStream
	// 기반 스트림  : FileInputStream
	try (ObjectInputStream ois = new ObjectInputStream(
			new FileInputStream("file2.txt"))
			) {
		System.out.print(ois.readObject());
		
	}catch(IOException | ClassNotFoundException e) {
		 e.printStackTrace();
	}
	/*catch (IOException e) {
		  e.printStackTrace();
	  }catch (ClassNotFoundExcpetion e) {
		  e.printStackTrace();
	  }*/
}
}
