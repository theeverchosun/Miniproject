package com.kh.ex2.model;

public interface TouchDisplay {

	public String touch();
}
