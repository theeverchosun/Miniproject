package com.kh.method;

public class Method1 {
	/*
	 * 메소드 : 함수. 클래스 내에서 특정 기능을 묶어놓은 부분.
	 * 표현법
	 * 접근제한자 예약어(생략가능) 반환형 메소드명  (매개변수){ 실행할내용}
	 */

	public static void main(int[] args) {
		
		RD();
		
		
	}

	
/*
 * 메소드 실행시  "HI everyone"을 콘솔창을 출력
 * 
 * main 메소드에서 호출할 예정
 * 
 * 
 */
	public static void hE() { 
		System.out.println("BYE Everyone!");
		
	}
	/*
	 * 메소드 실행시 이름(name)을 전달받아
	 * 안녕하세요 name님을 콘솔창을 출력
	 * 
	 * 
	 */
	public static void NM(String name) {
		System.out.println("안녕하세요"+ ""+name+"님");
	}
	/*
	 * 1~100사이의 랜덤값을 추출하여 결과값을 전달
	 * 
	 * 
	 */
	public static int RD() {
		
		int random = ((int)Math.random()*100 + 1);
		return random;
	}
	/***
	 * 메소드 실해 1부터 전달받은값(end)사이의 랜덤값을 추출하여 결과값으로
	 * 
	 */

}
