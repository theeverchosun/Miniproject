package com.kh;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class B_IoStream {

	public static void main(String[] args) {
		//키보드를 입력  --> 프로그램으로 가져오고 --->콘솔창으로 출력
		
		InputStream in = System.in;
		
		OutputStream out = System.out;
		
		byte[] buf = new byte[8192];
		
		int len = 0;
		
		
		try {
		len= in.read(buf);
		
		out.write(buf, 0, len);
		out.flush();
		
		} catch(IOException e) {
			e.printStackTrace();
		} finally {
			try	 {
				in.close();
				out.close();
			}catch(IOException e) {
				e.printStackTrace();
		}
		

	}

	}

}