package com.kh.ex1;

public class Run {

	public static void main(String[] args) {
		System.out.println("---메인스레드 시작---");
		
		//Runnable 인터페이스 구현
		
		Thread t1 = new Thread(new task1());
		t1.start();
		
		
		Thread t3 = new Thread ()->{
			String threadName = Thread.currentThread().getName();
			System.out.println("실씰행중");
		}
		
		t3.start();
		//상속시킨 스레드
		Task2 t2 = new Task2();
		
		t2.start();
		
		
		System.out.println("---메인스레드 종료---");

	}

}
