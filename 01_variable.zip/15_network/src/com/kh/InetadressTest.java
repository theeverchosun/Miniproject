package com.kh;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class InetadressTest {

	public static void main(String[] args) {
		//localhost => 내pc
		
		try {
			
		InetAddress localhost = InetAddress.getLocalHost();
		System.out.println(localhost.getHostName());
		System.out.println(localhost.getHostAddress());
		
		System.out.println("=".repeat(20));
		
		String domain ="www.ondisk.net";
		InetAddress[] naverHost = InetAddress.getAllByName(domain);
		
		for(InetAddress addr : naverHost ) {
			System.out.println(addr.getHostName());
			System.out.println(addr.getHostAddress());
		}
		
		}catch(UnknownHostException e) {
			e.printStackTrace();
		}
		
	}

}
