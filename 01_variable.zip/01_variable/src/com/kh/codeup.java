package com.kh;

import java.util.Scanner;

public class codeup {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
		int d = a+b+c ;
		double e = d/3.0;
		
		System.out.println (d);
		System.out.printf ("%.1f", e);
		
		
		
		
		
	}


}
