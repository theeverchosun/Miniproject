package com.kh;

import java.util.Scanner;

public class Quiz3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("나이 :");
		int age = sc.nextInt();
		
		System.out.print("키 :");
        double hei = sc.nextLong();
        
        String result = age <= 12 || hei <= 130.0 ? "보호자 동반 필수" : "단독 탑승 가능";
        System.out.println(result);
        
        sc.close();
	}

}
