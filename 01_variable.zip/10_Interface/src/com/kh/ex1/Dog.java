package com.kh.ex1;

public class Dog implements Animal, Baby {
	/*
	 * void ();
	 * void eat();
	 * void make();
	 */
	public void move() {
		System.out.println("네발로걸어갑니다");

	}
	
	//@Override
	
	public void makesound() {
		
		
		System.out.println("멍멍");

		
		
	}
	//@Override
	
	public void eat() {
		System.out.println( "뼈다귀를 먹습니다");
	}
	
	

}
