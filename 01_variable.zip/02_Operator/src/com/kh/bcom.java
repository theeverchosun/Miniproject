package com.kh;

public class bcom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
