package com.kh.run;

import java.util.HashSet;
import java.util.Set;

import com.kh.mode.set.Studen;

public class SetRUS {

	public static void main(String[] args) {
		//선언 및 생성
		
		Set<Studen> set = new HashSet<>();
		
		set.add(new Studen("조로",25,77.5));
		
		set.add(new Studen("베스",35,87.5));
		
		set.add(new Studen("구르",45,37.5));

		set.add(new Studen("조로",25,77.5));
		
		System.out.println("저장된 학생 수"+set.size());
		
		for(Studen s : set) {
		System.out.println(s);
		
	}
	
	
	}

}
