package com.kh;

public class B_String {

	public static void main(String[] args) {
		
 test2();
		
		
		
		
		
		
	}
	
	
	public static void test1() {
		
		String st1 ="Friday";
		String st2 ="Friday";
		
		System.out.println(st1 == st2);
		//결과가 true인이유
		// 문자열값자체(리터럴) 대입하게되면 상수풀 저장되어 같은곳(주소값)을 가리키게 됨
		
		System.out.println(st1 == "Friday");
		//st1이 가리키는 주소와 Friday라는 값자체의 저장된주소가 같기때문이다.
		
		System.out.println("==========");
		String st3 = new String("Friday");
		String st4 = new String("Friday");
		
		System.out.println( st3 == st4);
		//결과 false 문자열 객체를 생성해서 값을 대입하게 되면
		//메모리에 새로운 영역에 할당하므로 각각 다른위치에 값이 저장됨
		
		System.out.println(st3 == "Friday");
		//st3은 새로운공간에 저장되고 Friday는 상수풀에 저장되어있어 주소값이 다르다.
		//문자열의 값을 비교할때 equals
		System.out.println(st3.equals("Friday"));
		
		System.out.println("==========");
		
		String st5 = "Good";
		String st6 = "Luck";
		
		System.out.println(st5.toString());
		//object의 toString => 클래스명@해시값
		//주소값(해시값)을 반환하는 메소드 : System.identityHashCode(참조변수)
		int hash = System.identityHashCode(st5);
		System.out.println(hash);
		//문자열을 합쳐주는 메소드 :concat()
		st5 = st5.concat(st6);
		System.out.println(st5);
		int hash2 = System.identityHashCode(st5);
		System.out.println(hash2);
		
		
		
	}

	public static void test2() {
		String str1 = "Hello";
		//toUpperCase : 알파벳 대문자로 변환
		//toLowerCase : 소문자로 변환]
		System.out.println(str1.toUpperCase());
		System.out.println(str1.toLowerCase());
		//contains : 문자열내에서 특정 문자열이 포함되었는지 여부를 확인
		System.out.println(str1.contains("el"));
		System.out.println(str1.contains("yux"));
		
		//indexOf: 문자열내에 특정 문자열이 포함되어있는 시작위치 리턴(int)
		System.out.println(str1.indexOf("el"));
		System.out.println(str1.indexOf("xx"));
		
		//substring: 문자열.substring(시작인덱스)=> 문자열에서 시작인덱스부터 마지막위치까지 추출하여 반환
		//문자열.substring(시작인덱스,끝인덱스) = > 문자열에서 시작인덱스부터 끝인덱스전까지 부분을반환
		
		System.out.println(str1.substring(2));
		System.out.println(str1.substring(2, 5));
		//repeat:문자열을 지정한갯수만큼 반복하여 반환
		
		System.out.println(str1.repeat(5));
		System.out.println("=".repeat(50));
		//split : 문자열을 특정 구분자를 기준으로 분리하여 문자열 배열 형태로 리턴
		
		String str2 ="JAVA#SQL#HTML#CSS";
		String[] arr = str2.split("#");
		
		for(String s : arr) {
			System.out.println(s);
		}
		
	}
	
}
