package com.kh.ex1;

import java.util.Scanner;



public class Quiz1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정사각형 한 변의 길이 :  ");
		int n1 = sc.nextInt();
		
		System.out.println("정사각형 한 변의 길이 : "+ n1);
		System.out.println("둘레의 길이 : "+ (n1 * 4));
		System.out.println("넓이 : "+ (n1 * n1));
		
		

	}

}
