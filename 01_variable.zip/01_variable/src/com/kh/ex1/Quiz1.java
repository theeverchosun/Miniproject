package com.kh.ex1;

import java.util.Scanner;

public class Quiz1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("이름 입력 : ");
		
		String name = sc.nextLine();
		
		System.out.print("나이 입력 : ");
		
		int age = sc.nextInt();
		
		System.out.print("키 입력 : ");
		
		double tall = sc.nextDouble();
		
		
		
		
		System.out.println("이름 :" + name);
		//System.out.println("나이 :" + age+"세");	
		System.out.printf("나이 : %d세\n", age);
		System.out.println("키 :" + tall+"cm");	
		
		

	}

}
