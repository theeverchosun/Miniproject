package com.kh;

import java.io.File;
import java.io.IOException;

public class A_File {

	public static void main(String[] args) {
		method2();
	}
	
	public static void method1() {
		
		File f1 = new File("test1.txt");
		
		File f2 = new File("D:\\test2.txt");
		//존재하는 파일의 경우 따로 처리하는 내용이 없다.
		
		File f3 = new File("D:\\test3.txt");
		//특정 결로에 파일생성
		
		//존재하지 안흔 경로에 파일을 생성하면 예외발생
		//폴더 먼저 생성하고 그다음 파일생성
		File f4_folder = new File("D:\\temp");
		
		
		File f4 = new File("D:\\temp\\test4.txt");
		
		File f5 = new File("text5.txt");
		
	    
	    
		
		try {
		f1.createNewFile();
		
		f2.createNewFile();
		
		f3.createNewFile();
		
		f4_folder.mkdir();
		
		f4.createNewFile();
		
	    System.out.println("test1.txt가 존재하는기?"+f1.exists());
	    System.out.println("test5.txt가 존재하는기?"+f5.exists());
	    System.out.println("f4는 파일인가?"+f4.isFile());
	    System.out.println("f4폴더는 파일인가?"+f4_folder.isFile());
	    
		
		
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}
	//sampel 폴더를 생성하고 mydiary.txt
	
	public static void method2() {
		
		File S = new File("Sample");
	
		
		if(!S.exists()) {
			S.mkdir();
		}
		
		File md = new File("Sample\\mydiary.txt");
		try {
		if(!md.exists()) {
			md.createNewFile();
		}
		System.out.println("파일명 :"+md.getName());
		System.out.println("파일경로:"+md.getAbsolutePath());
		System.out.println("파일용량"+md.length());
		System.out.println("파일상위폴더"+md.getParent());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}

}
