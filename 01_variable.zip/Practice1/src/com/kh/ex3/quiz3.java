package com.kh.ex3;

import java.util.Scanner;

public class quiz3 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("상품명을 입력하세요: ");
		
	  
		String name = sc.nextLine();
		
		System.out.print("수량: ");
		
		int much = sc.nextInt();
		
	    System.out.print("단가: ");
		
		double prices = sc.nextDouble();
		
		/*--- 장바구니 영수증 ---
		상품명    : 아메리카노
		수량      : 3 잔
		단가      : 4100.50 원
		----------------------
		총 금액   : 12301.50 원
		*/
		
         System.out.println("--- 장바구니 영수증 ---");
         System.out.println("상품명 :"+name+ "");
         System.out.printf("%-7s:"+much+"잔\n", "수량");
         System.out.printf("%-7s: %.2f원\n","단가", prices);
         System.out.println("----------------------");
         System.out.printf("총 금액 : %.2f원", prices * much);
         
         
		
		
		sc.close();
}
}