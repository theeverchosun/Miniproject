package com.kh.pos.controller;

import com.kh.pos.model.CardPayment;
import com.kh.pos.model.Customer;
import com.kh.pos.model.MobilePay;
import com.kh.pos.model.PaymentMethod;

public class PosController {
	
	private Customer custom;
	private PaymentMethod[] pl;
	
	public  PosController() {
		pl = new PaymentMethod[4];
		
		pl[0] = new MobilePay("네이버페이",12,1000000,"NAVER");
		pl[1] = new MobilePay("토스페이",14,2000000,"TOSS");
		pl[2] = new CardPayment("국민나라사랑카드",12,500000,true);
		pl[3] = new CardPayment("신한체크카드",8,300000,false);
	}
	
	public void insertCustomer(Customer c) {
		
		custom = c;
		
		
	}
	public Customer getCustomerInfo() {
		return custom;
	}
	
	public PaymentMethod[] selectAllmethod() {
		return pl;
	
	}
	
	public PaymentMethod[] searchMethod(String keyword) {
		PaymentMethod[] result = new PaymentMethod[pl.length];
		int index =0;
		
		for(PaymentMethod method :pl) {
			String methodName = method.getName();
			if(methodName.contains(keyword)) {
			//	result[index] = method;
			//	index++;
				result[index++] = method;
			}
		}
		return result;
	}
	
	public int processPayment(int index) {
		PaymentMethod method  = pl[index];
		int customerAge = custom.getAge();
		int methodMinAge = method.getMinAge();
		
		if (method instanceof MobilePay && customerAge <= methodMinAge +3) {
			
			return 1;
		}
		if (customerAge < methodMinAge) {
			return 1;
		}
		if(method instanceof CardPayment && ((CardPayment) method).isHasCashback()) {
			
		int currpoint = custom.getPoints();
		custom.setPoints(currpoint+500);
			return 2;
		}
		
		
		return 0;
		
	}
	

}
