package com.kh.menu;

public class Drink {

	String name;
	int Price;
	
	public Drink() {
		
	}

	public Drink(String name, int price) {
		super();
		this.name = name;
		Price = price;
	}


	public String getName() {
		return name;
	}

	public int getPrice() {
		return Price;
	}

	public void order() {
		System.out.println("음료명"+name);
		System.out.println("가격"+Price);
	}
	
}
