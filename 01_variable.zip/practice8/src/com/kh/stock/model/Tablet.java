package com.kh.stock.model;

public class Tablet extends Device {
	
	private boolean supportStylus;
	
	public Tablet() {
		
	}

	public Tablet(String brand, String name, int price, boolean supportStylus) {
		super(brand, name, price);
		this.supportStylus = supportStylus;
	}

	@Override
	public String getInoformation() {
		// TODO Auto-generated method stub
		return String.format("태블릿 %s| 펜지원 여부: %s"
					, super.getInoformation()
					,(supportStylus)?"지원함":"지원안함");
		}
	}
	
	
	


