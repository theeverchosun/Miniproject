package com.kh.ex1;

public class Quiz1 {
	public static void main(String[] args) {
		
       /*====================
		*이름 : 홍길동
		*나이 : 20세
		*이메일: hong@gmail.com
		*====================
		*/
		System.out.println("====================");
		//System.out.println("이름 : 박기태");
		System.out.printf("이름: %s\n", "박기태");
		//System.out.println("나이 : 38세");
		System.out.printf("나이 %d세\n",38);
		System.out.println("이메일: hong@gmail.com");
		System.out.println("====================");
	}

}


