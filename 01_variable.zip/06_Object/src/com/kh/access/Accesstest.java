package com.kh.access;

/*
 *  접근 제한자 : 클래스 및 클래스 내부 멤버 ( 변수 메소드)의 접근권한을 제한
 *  1. 클래스에 사용 가능한 접근 제한자 (2가지)
 *  -public : 다른 패키지에서도 제한없이 사용 가능
 *  -default : 같은 패키지에서 접근 가능하다
 *  
 *  2.멤버(변수 메소드)에 사용가능한 접근 제한자 (4가지)
 *  public :어디서든 접근 가능하다
 *  protected : 같은 패키지 내이거나 또는 다른 패키지라도 상속관계면 가능하다
 *  deafault : 같은 패키지 내에서만 접근 가능
 *  private : 같은 클래스내에서만 접근 가능
 *  
 *  접근 가능한 범위
 *  (넓은) public > protected > default > private (좁음)
 *  
 *  클래스 접근 제한자 : public -> 어디서나  이 클래스를 인스턴스화(객체생성가능)
 *  
 */
public class Accesstest {

	// 필드부(변수부) : [접근제한자] [예약어] 자료형 변수명;
	public String PUF = "public 필드";
	protected String PRF = "protected 필드";
	String DFF ="default 필드";
	private String PVF ="private 필드";
	
	public void publicmethod() {
		System.out.println("public 메소드");
	}
	protected void protectedmethod() {
		System.out.println("protected 메소드");
	}
		void defaultmethod() {
			System.out.println("deafault메소드");
		}
			private void privatemethod() {
				System.out.println("privatge메소드");
			}
		
	}


