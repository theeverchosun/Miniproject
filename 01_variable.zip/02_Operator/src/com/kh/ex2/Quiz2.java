package com.kh.ex2;

import java.util.Scanner;

public class Quiz2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("지불한 돈 : ");
		int n1 = sc.nextInt();
		System.out.print("물건가격 : ");
		int n2 = sc.nextInt();
		
	    int n3 = n1 - n2;
	    
	    int n4 = n3/1000;
	    int n5 = (n3%1000)/100;
		
		System.out.println("--- 거스름돈 내역 ---");
		System.out.println("천원지폐 :"+n4+"장");
		System.out.println("백원동전 :"+n5+"개");
		
		sc.close();
		


	}

}
