package com.kh.access.run;
import com.kh.access.Accesstest;

public class Run {

	public static void main(String[] args) {
		Accesstest test = new Accesstest();
		
		System.out.println (test.PUF);
		
		//System.out.println(test.PRF);
		
		test.publicmethod();
		//test.protectedmethod();
	}

}
