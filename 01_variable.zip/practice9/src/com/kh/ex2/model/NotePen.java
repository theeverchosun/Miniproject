package com.kh.ex2.model;

public interface NotePen {
	
	public boolean PEN_BUTTON=true;
	
	public boolean bluetoothPen();

}
