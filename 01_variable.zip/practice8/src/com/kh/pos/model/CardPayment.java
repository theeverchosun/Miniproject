package com.kh.pos.model;

public class CardPayment extends PaymentMethod{
	
	private boolean hasCashback;
	
	public CardPayment() {
		
	}

	public CardPayment(String name, int minAge, int transactionLimit, boolean hasCashback) {
		super(name, minAge, transactionLimit);
		this.hasCashback = hasCashback;
	}
	
	public boolean isHasCashback() {
		return hasCashback;
	}

	public void setHasCashback(boolean hasCashback) {
		this.hasCashback = hasCashback;
	}

	public String toString( ) {
		return String.format("신용/체크카드 - 카드명: %s | 캐시백 여부: %s",
				super.toString(), hasCashback ? "캐시백가능" : "캐시백없음");
	}

}
