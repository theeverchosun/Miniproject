package com.kh;

public class A_arraybasic {

	public static void main(String[] args) {
		
		method2();

/*
 * 변수 :하나의 이름으로 하나의 데이터를 다루는것
 * 배열 : 하나의 이름으로 여러개의 데이터를 다루는것
 * 
 * -선언 여러개의 데이터을 다루기 위한 배열의 형태를 선언
 * 자료형[]변수명; //권장*
 * 자료형 변수명 [];
 * -생성(할당) : 배열에 몇개의 데이터를 저장할 것인지 크기를 지정하여 공간 할당
 * 
 * 변수명 = new 자료형[배열크기];
 * 
 * -선언과 동시에 할당
 * 자료형[] 변수명 = new 자료형[배열크기];
 * 
 * - 값 대입 => 각 위치에 값을 저장. 인덱스를 사용하여 저장
 * 인덱스는 0부터 시작
 * 변수명[인덱스] = 값;
 * -초기화 => 배열 선언과 동시에 값을 한번에 저장
 * 자료형[] 변수명 = new 자료형[] {값1, 값2, 값3,....}
 * 자료형[] 변수명 = {값1, 값2, 값3,....}
 */
		
		
		

	}
	
	public static void metho1() {
		// 정수형 arr 선언
		
		int[] arr;
		// arr 변수의 크기가 5인 배열생성
		 arr = new int[5];
		 
		 //arr = [ 0 0 0 0 0]
		 
		 //값 대입 - 각위치에 저장 0번위치부터 4번깢
		 arr[0] = 1;
		 arr[1] = 2;
		 arr[2] = 3;
		 arr[3] = 4;
		 arr[4] = 5;
		 
		 System.out.print(arr[0]+arr[1]+arr[2]+arr[3]+arr[4]);
		 
		 
		
		
	}
	
	public static void method2() {
		
		// 배열크기 배열명.length
		int[] arr1 = new int[5];
		
		for(int i=0; i<arr1.length; i++) {
			
			arr1[i] = i*10;
			
			System.out.println(arr1[i]);
			
			
		
		}
		
		
		
		
	}

}
