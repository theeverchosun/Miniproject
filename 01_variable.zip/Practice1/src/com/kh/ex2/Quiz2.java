package com.kh.ex2;
import java.util.Scanner;

public class Quiz2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
	
		System.out.print("이름 입력: ");
		
	 
		String name = sc.nextLine();
		
		System.out.print("나이 입력: ");
		
		int age = sc.nextInt();
		
		System.out.println(name+"("+age+"세) java학습을 축하합니다");
		
	    System.out.printf("\n %s님(%d세)의 생일을 축합니다",name ,age);
		

		
		sc.close();
		
	}

}
