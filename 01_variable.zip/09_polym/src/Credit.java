
//상속관게적용 : .extends
public class Credit extends PaymentMethod {
	

	private String cardNumber;
	private int installment;
	
	public Credit() {
		
	}
	
	public Credit(String payName, int payAmount, String cardNumber, int installment) {
		
		//setPayName(payName);
		//setPayAmount(payAmount);
		super(payName, payAmount); //맨첫줄에 있어야한다
		this.cardNumber = cardNumber;
		this.installment = installment;
	}
	
	
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public int getInstallment() {
		return installment;
	}
	public void setInstallment(int installment) {
		this.installment = installment;
	}

public void processPay() {
	System.out.println("카드결제정보");
	System.out.println("- 결제 금액 : " + getPayAmount());
	System.out.println("카드번호 :"+ cardNumber);
	System.out.println("할부 개월수 :"
			+(installment ==0 ? "일시불" : installment + "개월"));
}
/*
 * if (installmen =0) {
 *  System.out.println( "-할부 개월수 : 일시불");
 *  }else {
 *  System.out.println("-.할부 개월수 :installment + "개월");
 */
}
