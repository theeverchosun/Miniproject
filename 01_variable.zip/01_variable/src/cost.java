
public class cost {
	public static void main(String[] args) {
		//method1(); 
		method2();
		
	}
	
	public static void method2() {
		
		System.out.println("method2() start ....");
		//1.논리형 boolean : true 또는 false 을 저장하는 자료형
		boolean isTrue = true;
		boolean isFalse = false;
		 
		System.out.println("istrue의 값"+ isTrue);
		
		isFalse = -10 > 2 + 3;
		
		System.out.println("-10 > 2+3 의 결과" +isFalse);
		
		//2. 숫자 정수형 실수형
		// byte(1B) short(2B) int(4B) long(8B)
		// bye 자료형 bNum 선언하고 저장할수있는 범위내 최소값 대입(저장)
		
	      long bNum = 1000;
	      long bNum2 = 1000l;
		
		System.out.println(bNum);
		
		// 실수형 소수점 포함한 숫자
		// float (4byte)/ double(8byte)
		//floay 자료형  변수 fNum에 0.0을 저장
		
        float fNum = 0.0f;
        //dobule 자료형 변수
        
        double dNum;
        
        dNum = 0.002;
        
        //문자형 (char String)
        
        //a라는 값을 저장하는 변수 ch선언
        
        char a;
        
         a = 1;
         char  kim = '김';
         
         //문자형 String
         
         String txt;
         
         //txt변수에 안녕하세요 저장
         
         txt = "안녕하세요~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
         
         //txt의 데이터 길이 ; 변수명.length()
         
         //상수 고정된값 리터럴 
         //*final 자료형 변수명;
         //최대 이용자 수를 저장하기 위한 상수 선언 : max users
         
         final int MAX_USERS;
         
         MAX_USERS = 28;
         
         
         
         
         
        System.out.println("txt의 길이 :"+txt.length());
        
        
        System.out.println(fNum);
	
	}
	
	public static void method1() {
		int minwage = 10320;
		
		System.out.println("홍길동" + minwage*8*5+"원");
        System.out.println("아이유" + minwage*6*5+"원");
        System.out.println("나루토" + minwage*10*3+"원");
        System.out.println("짱구" + minwage*4*7+"원");
        System.out.println("루피" + minwage*6*10+"원");
	}
}
