package com.kh.ex1.Run;

import java.time.LocalDate;
import java.util.Scanner;

public class Run {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	
		
		System.out.print("주민번호 입력 :");
			String ssn = sc.nextLine();
			
			if(ssn.length() != 14) {
				System.out.println("잘못입력했습니다");
			}else {
				String result = "";
				String ssnYear	= ssn.substring(0,2);
				char gender = ssn.charAt(7);
				int birth = 0;
			
				if(gender=='1'||gender=='2') {
					birth = (1900 + Integer.valueOf(ssnYear));
				}else if (gender==3||gender==4) {
					birth =(2000+Integer.valueOf(ssnYear));
					
				}
				if(gender == '1' || gender =='3') {
					
					result += "/성별 남성";
				}else if (gender =='2'||gender=='4') {
					result +="/성별 여성";
				}
	    int curr = LocalDate.now().getYear();
		int age = curr - birth + 1;
			result +="/나이:" +age +"세";
			
			System.out.println(result);
		    
			}
			
		

	}

}
