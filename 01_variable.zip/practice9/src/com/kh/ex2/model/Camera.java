package com.kh.ex2.model;

public interface Camera {
	
	public String picture();

}
