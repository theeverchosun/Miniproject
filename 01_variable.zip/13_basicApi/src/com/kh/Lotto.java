package com.kh;

import java.util.HashSet;
import java.util.Set;

public class Lotto {

	public static void main(String[] args) {
		lotto();


	}
	
	public static void lotto() {
		
		Set<Integer> numbers = new HashSet<>();
		
		while(true) {
			
			int random = (int)(Math.random()*45+1);
			numbers.add(random);
			
			if(numbers.size()==6) {
				break;
			}
		}
		System.out.print(numbers);
		
	}

}
