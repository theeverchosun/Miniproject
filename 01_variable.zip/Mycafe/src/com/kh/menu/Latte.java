package com.kh.menu;

public class Latte extends Drink {

	public Latte(String name, int Price) {
		super(name, Price);
	}

	@Override
	public void order() {
		System.out.println("얼음을 채웁니다");
	}
	

}
