package com.kh.run;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.kh.model.sort.Studen;

public class Run {

	public static void main(String[] args) {
		//선언 및 생성
		List<Studen> list = new ArrayList<>();
		
		list.add(new Studen("박기태",39,85.5));
		
		list.add(new Studen("이가람",29,65.5));
		
		list.add(new Studen("아보르",19,75.5));
		
		System.out.println("현재 저장된 학생수 :"+ list.size());
		
		for(int i=0; i<list.size(); i++) {
			
			System.out.println(list.get(i));
		}
		// 첫번째 학생 제거
		
		list.remove(0);
		System.out.println("현재 저장된 학생수 :"+ list.size());
for(int i=0; i<list.size(); i++) {
			
			System.out.println(list.get(i));
		}

          Collections.sort(list);
		
		

	}

	

}
