package com.kh.mode.set;

import java.util.Objects;

public class Studen {
	
	private String name;
	private int age;
    private double score;
//name필드의 getter 메소드
    
    public Studen() {
    	
    }
    
    public Studen(String name, int age, double score) {
    	this.name = name;
    	this.age = age;
    	this.score = score;
    	
    }
    // 
    public String getName() {
    	return name;
    }
    //name 필드의 setter 메소드
    public void setName(String name) {
    	this.name = name;
    	
    }
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public static void main(String[] args) {
		

	}

	@Override
	public String toString() {
		return "Studen [name=" + name + ", age=" + age + ", score=" + score + "]";
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return Objects.hash(name,age);
	}

	@Override
	public boolean equals(Object obj) {
		
		if(this==obj) {
			return true;
		}
		//전달된 객체가 비어있는 겨우
		if(obj==null) {
			return false;
		}
		 Studen other = (Studen)obj;
		return this.name.equals(other.name) && this.age == other.age;
	}
	
	

}
