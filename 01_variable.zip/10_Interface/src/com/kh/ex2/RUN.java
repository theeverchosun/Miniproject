package com.kh.ex2;
import java.util.Scanner;


public class RUN {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		
		Shape[] arr = new Shape[2];
		
		arr[0] = new Circle(5);
		arr[1] = new Rectangle(3, 4);
		
		for(Shape s : arr) {
			if (s instanceof Circle) {
				System.out.print("원의 넓이 :");
			}else if ( s instanceof Rectangle ) {
				System.out.print("사각형의 넓이");
			}
			
			System.out.println(s.caculateArea());
		}
		
		
		
		 
		
		

	}

}
