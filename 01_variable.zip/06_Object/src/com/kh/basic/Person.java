package com.kh.basic;

public class Person {
	
	/*
	 * 클래스 구조
	 * 
	 * 접근제한자 class 클래스명 {
	 * 변수부 (필드부)
	 * :데이터를 저장할 공간을 선언하는 부분
	 * 생성자부
	 * :객체를 생성하기 위한 특별한 메소드를 정의하는 부분
	 * 데이터를 초기화하기 위한 목적으로 정의
	 * 메소드부
	 * :기능을 정의하는 부분
	 * 
	 */

	/*
	 * 추상화 해보기 :객체를 어떻게 표현할것인지 정리하는 과정
	 * 
	 * 사람 객체 설정
	 * 1. 떠어로는것들을 나열해보기
	 *  이름 나이 성별 직업 국적 키 취미
	 *  2. 필요한 항목들만 추려내기
	 *  이름 나이 성별 말하다 울다
	 *  3 저장할 데이터의 형태를 정리해보기
	 *  이름 => 문자열 (Stirng)
	 *  나이 => 정수 (int)
	 *  성별 => 문자 (char)
	 *  
	 *  변수부
	 *  s
	 *  
	 */
   String name ; 
   int age ;
   char gender;
   
   
   //생성자부
   //특징 반환형이 없다,  생성자명과 클래스명이 동일
   public Person() {
	   System.out.print(name + "," + age + ","+ gender);
	   //기본 생성자 : 정의된 생성자가 없는 경우 자동으로 만드어짐 
	}
  
   public Person(String name, int age, char gender) {
	   
	   this.name = name;
	   this.age = age;
	   this.gender =gender;
	   
   }
   
   /*
    * 메소드부
    * 
    * 소개하는 메소드
    * 저장된 이름  나이 성별 정보를 출력
    * 
    * 접근제한자 예약어 반환형 메소드명(매개변수){
    * 실행할 내용}
    * 
    */
  
   public void intr() {
	   System.out.println(this.name+","+this.age+","+this.gender);
   }
   
   public void ccr(String ee) {
	   
	   System.out.println("안녕하세요");
	   
   }
   public void cry() {
	   
	   System.out.println("엉엉");
   }
   
}
   


