package com.kh.access;

public class Rucaccesss {

	public static void main(String[] args) {
		
		Accesstest test = new Accesstest();
		
		String pf = test.PUF;
				System.out.println("public 변수 :"+ pf);
		
				test.publicmethod();
		
				String pt = test.PRF;
				
				System.out.println("protect .변수" +pt);
				
				test .protectedmethod();
				
				String df = test.DFF;
				
				
                System.out.println("deafult .변수" +df);
				
				test .protectedmethod();
				
				//String pv = test.PVF;
				
				 //System.out.println("deafult .변수" +pv);
					
					//test .privatemethod();
	}

}
