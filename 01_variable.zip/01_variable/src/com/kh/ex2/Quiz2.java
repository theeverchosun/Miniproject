package com.kh.ex2;

public class Quiz2 {
	
	public static void main(String[] args) {
		
		int a = 10;
		int b = 20;
		
		System.out.println("교환전 a =" +a+  "교환전 b =" +b);
		
		
		int x = a;
		int v = b;
		
	    
		
		
		a = v;
		b = x;
		
		System.out.println("교환전 a =" +a+  "교환전 b =" +b);
		
		
		
	}

}
