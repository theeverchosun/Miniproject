package com.kh.run;

import java.util.HashMap;
import java.util.Map;

import com.kh.Model2.Studen;

public class MapRun {

	public static void main(String[] args) {
		Map<String,Studen> map = new HashMap<>();
		//데이터 put
		map.put("이장",new Studen("이장",25,77.5));
		map.put("과장",new Studen("과장",35,67.5));
		map.put("사장",new Studen("사장",45,87.5));
		
		Studen s = map.get("키");
		
		if(s!=null) {
			System.out.println(s);
		}else {
			System.out.println("해당 데이터가 없습니다");
		}
		
		for(Map.Entry<String, Studen> entry :map.entrySet()) {
			System.out.println("키"+entry.getKey()
			+"value"+entry.getValue());
		}

	}

}
