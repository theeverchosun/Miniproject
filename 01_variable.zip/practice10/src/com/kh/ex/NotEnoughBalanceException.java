package com.kh.ex;

public class NotEnoughBalanceException extends Exception {
	
	private int balance;
	private int withdrawAmount;
	
	public  NotEnoughBalanceException(String message, int balance, int withdrawAmount) {
		super(message);
		this.balance = balance;
		this.withdrawAmount = withdrawAmount;
	}

	public int getBalance() {
		return balance;
	}

	public int getShortfallAmount() {
		if (withdrawAmount > balance) {
            return withdrawAmount - balance;
        } else {
            return balance - withdrawAmount;
        }
    }
}
