package com.kh.ex1.model.vo;

public class Product {

	private String productname;
	private int price;
	private String brand;
	
	//아이폰16 / 1000000 / 애플
	//갤럭시 S25 / 1350000 / 삼성
	
	
	public Product() {
	
	}
		
	public String getProductName() {
		return productname;
	}
	
	public void setProductName(String productName) {
		
		this.productname = productName;
	}
	
	public int getPrice() {
		return this.price ;
	}
	
	public void setPrice(int price) {
		
		this.price = price;
		
	}
	
	public String getBrand() {
		return this.brand;
	}
	
	public void setBrand(String brand) {
		
		this.brand = brand;
	}

	
	public void information() {
		
		System.out.print(this.productname+" / "+this.price+" / "+this.brand);
	}
}
