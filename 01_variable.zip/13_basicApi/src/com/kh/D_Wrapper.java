package com.kh;

public class D_Wrapper {
	/*Wrapper 클래스 : 기본 자료형을 객체화해주는 클래스
	boolean - B
	char - Character
	byte - Byte
	short - Short
	int - Integer
	long - Long
	float - Float
	double - Double
	
	기본자료형을 객체화하는 이유
	-다형성을 적용시키고 싶을때
	- 매개변수로 기본자료형이 아닌 객체타입만 요구할때
	- 제네릭을 적용시키고 싶을때

*/
	public static void main(String[] args) {
		// 박싱boxing : 기본자료형 -- >Wrapper 클래스
		//언방식unboxing : 기본자료형 <---Wrapper 클래스
		int n1 = 200;
		int n2 = 200;
		
		//n1.equals(n2); - 기본자료형은 equals사용불가
		//Wrapper 클래스로 변환
		Integer i1 = Integer.valueOf(n1);
		Integer i2 = n2;
		
		System.out.println(i1);
		System.out.println(i2);
		
		
		System.out.println(i1.equals(i2));
		System.out.println(i1.compareTo(i2));
//compareTo 두값을 비교하여 앞쪽의 값(i1)의 크기값이 크면 1반환
		//뒤쪽의 값이 크면 -1 같으면 0
		//래퍼 클래스는 보통 "문자열" 래퍼클래스로 변환시키고자할대 사용
		
		Integer i3 = Integer.valueOf("500");
		Integer i4 = Integer.valueOf("777");
		
		Double d1 = Double.valueOf("3.14");
		
		//언방식
		int n3 = i3.intValue();//수동 언박싱
	    
		
	}

}
