package com.kh.game;

public class GameState {
	
	private String[] words = {"thread","happy","interface","abstract","smile"};
	
	private int wordIndex = 0;
	
	private String targetWord = words[wordIndex++];
	
	private int remainingTime = 10;
	
	private boolean isRunning = true;
	
	private int score = 0;
	
	//타이머 역할을 하는 메소드
	public synchronized void decreaseTime() {
		if (!isRunning) {
			return;
		}
		//제한시간 1감소
		remainingTime--;
		
		System.out.println("\n".repeat(3));
		System.out.println("[점수"+score+"]남은 시간:"+remainingTime+"초");
		System.out.println("제시어: " +targetWord );
		
		
		// 제한 시간이 0보다 작거나 같을 때
		
		if(remainingTime<=0) {
		isRunning = false;
		}
		
	}
	public synchronized void checkAnswer(String input) {
		if(!isRunning) {
			return;
		}
		
		if(input.equals(targetWord)) {
			System.out.println("정답입니다");
			score += 10;
			
			if(wordIndex == words.length) {
				wordIndex = 0;
			}
			targetWord = words[wordIndex++];
			remainingTime = targetWord.length();
			
		}else {
			System.out.println("오답입니다 다시");
			System.out.print("입력");
		}
	}
	public synchronized boolean isGameRunning() {
		
		return isRunning;
	}
	
	public int getScore() {
		return score;
	}
	

}
