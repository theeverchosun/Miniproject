package com.kh.ex2.controller;
import java.time.LocalDateTime;

import com.kh.ex2.controller.Customer;

public class StudyCafeController {
	
	Customer[] customers;
	int customCount;
	
	
	
	public StudyCafeController() {
		customers = new Customer[100];
		customCount = 0;
	}



	/**
	 * @return the customCount
	 */
	public int getCustomCount() {
		return customCount;
	}
	
	
	public String registerCustomer(String id) {
		if(findCustomerById(id) !=null) {
			return"[오류] 이미 등록된 회원입니다";
		}
		if (customCount>customers.length){
			return"[오류] 등록 정원을 초과했습니다. 가입할 수없습니다";
		}
		
		if (customCount<customers.length) {
			customers[customCount++] = new Customer(id);
			return"[안내] 신규회원이 등록이 완료되었습니다.(오픈기념 보너스30분 지급!)";
		}
		
		
		
	}
	
	public String checkIn(String id ) {
		//고객 목록(배열)에서 고객 번호 찾기
		Customer fc = findCustomerById(id);
		if(fc != null) {
			fc.setCheckdln(true);
			fc.setChecklnTime(LocalDateTime.now());
			return"[안내]입실 처리가 완료되었습니다";	
		}else {
			return"[오류] 등록되지않은 회원입니다";
			
		}
	}

	private Customer findCustomerById(String id) {
		for (Customer c : customers) {
			if(c!=null&&c.getId().equals(id)) {
				return c;
			}
		}
		return null;
	}


		
	}


