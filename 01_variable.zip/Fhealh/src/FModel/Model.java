package FModel;

public class Model {
	private String name;
	private String gender;
	private int age;
	private double height;
	private double weight;
	
	public Model() {
		
	}

	public Model(String name, String gender, int age, double height, double weight) {
		super();
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.height = height;
		this.weight = weight;
	}

    public double calculateBMI() {
       
        if (height <= 0) return 0; 
        return weight / (height * height);
    }
    public boolean isRequiresSpecialCare() {
        double bmi = calculateBMI();
        	

        String userGender = getGender(); 

        if (userGender.equals("남") || userGender.equals("남자")) {
            return bmi >= 25.0 || bmi < 18.5;
        } 
        else if (userGender.equals("여") || userGender.equals("여자")) {
            return bmi >= 24.0 || bmi < 18.5;
        }
        
        return false;
    }




	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}



}
