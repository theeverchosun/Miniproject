package com.kh.ex1.model.vo;

public class Television implements RemoteControl{
	
	private int volume;


public Television() {
	
	
}


public Television(int volume) {
	super();
	this.volume = volume;
}


@Override
public void turnOn() {
	System.out.println("tv를 켭니다.");
	
}


@Override
public void turnoff() {
	System.out.println("tv를 끕니다.");
	
}


@Override
public void setVolume(int volume) {
	// 최대 볼률은 10~0으로 제한
	if (volume >=0 && volume <=10) {
		this.volume =volume;
		System.out.println("Tv 볼률을"+ volume+"조절합니다");
	}else {
		System.out.println("Tv볼륜 범위에 해당하지 않습니다");
	}
}


	

}
