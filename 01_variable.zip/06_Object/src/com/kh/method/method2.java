package com.kh.method;

public class method2 {
	/*
	 * 매소드 오버로딩
	 * 한 클래스내 같은이름의 메소드가  매개변수의 개수 타입 순서가가 다를때 여러번 존재할수있다
	 * 
	 * 
	 * 
	 */

	public static void main(String[] args) {
		
		int result = add(50,10);
		double reuslt2 = add(11.0,42.2);
		
		System.out.println(result);
		
		System.out.println(reuslt2);
		

	}
	
	/**
	 * add 메소드
	 * 두정수의 합을 반환하는 메소드
	 * 두 실수의 합을 반환하는 메소드
	 * 전달받아야하는 값 = > 0 . 2개를 전달받아야함
	 * 
	 * 결과값 = > 0.1 개 
	 */
	public static int add(int n1, int n2) {
		return n1 + n2;
	}
	
	public static double add(double n3, double n4) {
		return n3*n4;
	}
	
	/*오버로딩이 적용되지않는 이유
	 * 
	 */

}
