package c1ex;

public class ex2 {

	public static void main(String[] args) {
		
		int A = 4;
		
		for (int i = A; i >= 1; i--) {
			
			for(int j = i; j >= 1; j--) {
				
				System.out.print("*");
			}
			
			System.out.println();
			
		}
		
		
		
	}

}
