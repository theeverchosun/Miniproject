package com.kh.run;
import java.util.Arrays;
import java.util.Scanner;

import com.kh.model.Studen;
/*ctrl + shift + o
 * 객체배열 :여러개의 객체를 저장하여 관리하는 구조
 * 
 * !주의!
 * :배열을 생성(new 클래스명[크기]한다고 실제 객체를 생성하느것 아니라 객체의 주소를 담아둘수
 * 있는 참조변수만 만들어짐
 * 
 * 선언 : 클래스명[] 변수명;
 * 할당(생성) : new 클래스명[배열크기];
 * 
 * 값을 대입(객체생성)
 * 변수명[인덱스] = new 생성자;// 생성자 ->클래스명();
 * 
 * 초기화 
 *     변수명 = {new 생성자,new 생성장 ...}
 *     
 * 
 * 
 */

public class Run {

	public static void main(String[] args) {
		/*크기가 3인 정수형 배열 선언 및 할당
		 */
		int[] arr =new int[3];
		for(int i =0; i<arr.length; i++) {
			arr[i] = i+1;
		}
		System.out.print( Arrays.toString(arr));
		//학생정보를 담을 객체 배열 할당
		//학생 클래스(studen)
		// name : String
		// age : int
		// score : double
		// Student
		//Student(name:String age int score double
		//getter setter
		//printInfo():void
		
		Studen s1 = new Studen();
		
		Studen[] sarr = new Studen[3];
		// 배열에  각 학생 위치 정보 저장
		sarr[0] = new Studen("이므고",20,75.5);
		sarr[1] = new Studen("제르기스",70,85.5);
		sarr[2] = new Studen("오르비",14,55.5);
		
		// 두번째 학생 정보 출력
		// 1) 배열에서 몇번째 위치값으로 접근할것인지
		// 2) 학생 정보 출력 기능(메소드)가 있는지  없으면 getter 메소드 활용
		sarr[1].printInfo();
		//세번째 학생정보 삭제
		//sarr[2] = null;
		
		System.out.println("----------------");
		
		Scanner sc = new Scanner(System.in);
		
		Studen[] sarr2 = new Studen[2];
		//반복문을 사용하여  입력받은 값을 배열에 저장
		for(int i =0; i<sarr2.length; i++) {
			 System.out.print("이름 :");
			 String name = sc.next();
			 
			 System.out.print("나이 :");
			 int age = sc.nextInt();
			 
			 System.out.print("점수 :");
			 double score = sc.nextDouble();
			 
			 sarr2[i] = new Studen(name, age, score);
		}
		//출력 
		System.out.println(" 학 생 정 보");
		//for (자료형 변수명:배열명) {}
		for(Studen s : sarr2) {
			s.printInfo();
		}

	}

}
