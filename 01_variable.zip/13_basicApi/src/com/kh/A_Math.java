package com.kh;

public class A_Math {
/*
 * Math 클래스(java.lang)
 * 
 * 특징 모든 필드는 상쉬필드, 모든 메소드는 static 메소드
 * 생성자가 private으로 되어있음 -> 생성불가
 * => 싱글톤 패턴 : 한번만 메모리 영역에 올려놓고  재사용하는 개념
 */
	public static void main(String[] args) {
		
 System.out.println("파이:"+Math.PI);
 
 //랜덤값 변환 :random()
 
 System.out.println("랜덤값"+Math.random());
 
 //절대값 반환 : abs(값)
 int num = -132;
 System.out.println("절대값 :"+Math.abs(num));
 
 //제곱값 : pow(밑,지수)
 
 System.out.println("2의 10승 :"+ Math.pow(2, 30));
 
 //올림: ceil
 
 double num2 = 12.49;
 System.out.println("올림 :" +Math.ceil(num2));
 System.out.println("내림 :"+Math.round(num2));
 

 
 
	
	}

}
