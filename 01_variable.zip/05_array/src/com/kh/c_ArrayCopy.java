package com.kh;

public class c_ArrayCopy {

	public static void main(String[] args) {
		deepCopy();
		
		

	}
	/**
	 *얕은 복사 : 주소값(참조값)만 복사하는 방식
	 */
	
	public static void shallowCopy() {
		
		int[] origin = {1,2,3,4,5};
		
		System.out.println(" ====원본배열출력=====");
		for(int i=0; i<origin.length; i++) {
			System.out.print(origin[i]);
		}
		
		System.out.println();
		int[] copy = origin;
		
	   copy[2] = 333;
		//복사본 배열(copy)의 값을 출력
		
		for(int i =0; i<copy.length; i++) {
			System.out.println(copy[i]);
		}
	//복사본 배열의 3번째값을 333으로 변경
		
		
		
	}
	
	/**
	 * 	깊은 복사 : 새로운 배열을 생성하여 원본 배열값을 복사는 방식	
	 */
	
	public static void deepCopy() {
		int[] origin = {1,2,3,4,5};
		
		//복사본 배열 : 배열 선언후 원본 배열크기만큼 생성
		int[] copy = new int[origin.length];
		
		System.out.println ("데이터 복사전 copy 배열");
		//for(자료형 변수명: 배열명 ){변수명}
		// => 배열의 첫번째위치부터 마지막 위치까지 순차적으로 접근
		
		for(int item : copy) {
			System.out.print(item+" ");
		}
		System.out.println();
		// [1] 반복문(for) 사용하여 복사하기
		// 초기식에 선언한 변수를 인덱스로 사용
		for (int i = 0; i<origin.length; i++) {
			//복사본 배열 = 원본배열
			//복사본 배열의 i번째 위치 = 원본배열의 i번째 위치값
			copy[i] = origin[i];
		}
		origin[0] = 999;
		System.out.println("복사본후 copy배열");
		for(int data :copy) {
			System.out.print(data+" ");
		}
		
		System.out.println();
		
		for(int data :origin) {
			System.out.print(data+" ");
		}

//		System.arraycopy(원본배열명, 복사를 시작할 인덱스, 복사본배열명, 복사본배열의시작인인데스,복사할개수);
//		System.arraycopy(origin,0,copy,0,origin.length);
		copy = new int[10];
		//원본 데이터 [999,2,3,4,5]
		//복사후 데이터 [0,0,0,0,3,4,5,0,0,0]
		
		System.arraycopy(origin, 2, copy, 4, 3);
				
		System.out.println(" arraycopy로 복사");
		
		for(int  n : copy) {
			System.out.print(n +" ");
			
			
		}
		
	}
		
	}
	

