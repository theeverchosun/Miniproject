package com.kh.stock.run;

import com.kh.stock.model.Device;
import com.kh.stock.model.SmartPhone;
import com.kh.stock.model.Tablet;

public class Run {

	public static void main(String[] args) {
		
		Device[] div = new Device[3];
		div[0] = new SmartPhone ("Apple", "iPhone 15", 125000, "is");
		div[1] = new SmartPhone ("samsung", "galaxy s25", 115000, "Android");
		div[2] = new Tablet("Samsung", "galaxy tab s9", 98000, true);
		
		for(Device d : div ) {
			String info = d.getInoformation();
			System.out.println(info);
		}
	

	}

}
