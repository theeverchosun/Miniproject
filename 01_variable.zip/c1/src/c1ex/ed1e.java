package c1ex;

public class ed1e {

	public static void main(String[] args) {
		
		int num;
		num = 4;
		
		for(int i = 1; i<= num; i++) {
			
			for(int j =1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
