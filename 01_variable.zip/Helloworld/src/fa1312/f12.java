package fa1312;

public class f12 {

	public static void main(String[] args) {
		public void main(String[] args) {
	        String title = "Java의 정석"; 
	        String author = "남궁성"; 
	        int pageCount = "1022"; 
	        boolean isAvailable = 0; 

	        System.out.println("책 제목: " + title);
	        System.out.println("저자: " + author);
	        System.out.println("페이지 수: " + count);
	        System.out.println("대출 가능 여부: " + isAvailable);
	    }
	}


