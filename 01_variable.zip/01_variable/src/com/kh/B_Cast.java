package com.kh;

public class B_Cast {

	public static void main(String[] args) {
		
		forceCasting();
		
		
		//autoCasting();
		//형변환 테스트
		


	}
	
	public static void forceCasting() {
		
		/*
		 * 강제 형변환
		 * : 자동 형변환이 되지안흔 경우 직접해주는것
		 * 
		 * (변환할자료형)변환할대상
		 *주의점 강제형변환시 데이터 손실이 발생할수있다
		 */
		
		//실수형변수 d1에 4.0이라는 값을 저장
		
		//정수형 변수 i1에 50이라는 값을 저장
		
		// d1의 값에 i1의 값을 더해서 정수형 변수 result에 저장
		
		double d1 = 4.0;
		
		int i1 = 50;
		
		int result = (int)d1 + i1;
		
		System.out.println(result);
		
		int i2 = 290;
		byte i3 = (byte)i2;
		System.out.println(i3);
		
	}
	
	public static void autoCasting() {
		/*
		 * 자동 형변환
		 *  : 값의 범위가 좁은 자료형에서 넓은 자료형으로 자동 형변환
		 *  
		 *  
		 */
		// 정수형 변수 i1 12라는 값을 저장
		
		//실수형 변수 d1에 i1의 값을 저앙
		
		int i1 = 12;
		
		double d1;
		
		d1 = i1; //dobule = int >> double = double
		
		System.out.println("d1의 값"+d1);
		
	}
	
}
