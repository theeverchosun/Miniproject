package com.kh.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class TcpClient {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String serverIP = "192.168.30.27";
		int port = 1024;
		
		
		try {
		Socket sock = new Socket(serverIP,port);
		
		if(sock !=null) {
			BufferedReader br = new BufferedReader (
					new InputStreamReader(sock.getInputStream()));
			PrintWriter pw = new PrintWriter(sock.getOutputStream());
			while(true) {
				System.out.print("보낼내용:");
				String sendMessage = sc.nextLine();
				
				pw.println(sendMessage);
				pw.flush();
				
				String message = br.readLine();
				System.out.print("서버 :" +message);
			}
			
			
		}
		
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

}
