package com.kh.ex;

public class BankAccount {
	
	private int balance;
	
	public BankAccount(int intnitialBalance) {
		this.balance = intnitialBalance;
	}
	

	public int getBalance() {
		return balance;
	}


	public void withdraw(int amount) throws NotEnoughBalanceException {
		
		if (balance < amount) {
			throw new NotEnoughBalanceException("출금 오류 발생  잔액이 부족합니다"
					                                  ,balance, amount);
		}
		
		balance -= amount;
		System.out.println("출금완료 남은잔액:"+balance+"원");
	}
	
}
