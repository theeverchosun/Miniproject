
public class Run {

	public static void main(String[] args) {
		//Creit 클래스 객체 생성
		Credit card = new Credit("카드결제",10000,"123-123-123",0);
		// = 정적바인딩 : 참조 타입과 인스턴스(객체) 타입이 일치람
		// 물려받은 멤버 (부모 클래스의 정의된 멤버),내가 정의한 멤버(자식클래스의 멤버) 모두 접근가능
		
		card.processPay();  // 자식클래스 (Credit)에 정의된 멤버
		card.getPayAmount(); //부모 클래스(PaymentMethod)에  정의된멤버
        card.getCardNumber();//자식 클래스에만 정의된 멤버
        
        //부모타입참조변수에 자식객체 대입
        // 부모 타입 : PaymentMethod
        // 자식 타입 : Credit Pointpay
        
        PaymentMethod pm1 = new Credit();
        PaymentMethod pm2 = new Pointpay();
        // =>업캐스팅 : 클래스간 형변환
        // 가능한 이유? 상속관계이기 때문에
        // [1] 자바에서 상속관계는 "IS - A관계를 성립시킨다]
        // [2] 자식 인스턴스(객체)는 힙메모리에 생성시 부모의 멤버 공간을 항상 내포하고있다.
        //[3] 따라서 컴파일러는 부모타입의 참조변수로 자식 인스턴스를 가리키는것을 타입 안전하다고 판단한다
        // [4] 이변환은 형변환 연산자를 생략할수있는 "자동 형변환"으로 처리된다
        pm1.processPay(); //컴파일러는 해당 메소드가 PaymentMethod 클래스에 존재하기 때문에 문제 없는것으로 판단
        // => 동적바인딩
        //:컴파일 단계에서는 참조타입의 메소드와 연결(정적바인딩)되지만 
        // 실행단계에서는 실제 힙 영역에 있는 인스턴스 오버라이딩규격을 확인하고
        // 부모의 메소드가 아닌 자식의 오버라이딩된 메소드가 최종 호출되는것
        //String cardNumber = ((Credit) pm1).getCardNumber();
        //부모타입의 객체 배열 선언. 자식객체들로 구성
        
        // 배열 생성 : PaymentMethod로 크기가 3인 배열
        
        PaymentMethod[] arr = new PaymentMethod[3];
        //[null null null]
        //[카드결제 방식 포인트 결제 방식 카드결제 방식
        
        arr[0] = new Credit("카드결제",50000,"123-123-123-123",0);
        arr[1] = new Pointpay("카드",2000,5000);
        arr[2] = new Credit("카드결제",80000,"123-123-123-123",0);
        
        
        
        for(int i=0; i <arr.length; i++) {
        	arr[i].processPay();
        	// arr[i] : PaymentMethod 타입의 참조변수
          //processPay(); 동적바인딩
        }
        
        //* 다운 캐스팅 :업캐스팅으로 인해 제한된 자식 고유의 기능을 사용하기위해 자식타입으로 강제로 형변환을 의미
         // => 자식타입으로의 변환은 힙 메모리에 해당 영역이 존재하는지 컴파일러가 확신할수없으므로 
        // 반드시 명시적 형변환(강제 형변환)을 통해 처리해야한다 > 형변환 연산자 : (자식클래스명)참조변수
        // 주의  잘못된 타입으로  강제 변환시 ClassCastException 오류가 발생하므로
        // instanceof 연산자로 실제  객체 타입을 검증한 후 안전하게 다운캐스팅할수있다.
        // 카드 결제방식 - 카드 번호출력
        // 포인트 결제 방식 - 포인트 점수 출력
        // Todo 위 오류를 해결하여 이메일 제출
        
        for(int i=0; i <arr.length; i++) {
        	//참조 변수 instance of 확인할타입(자식클래스명) :boolean
        	// => ture  생성된 객체가 해당 타입으로 생성
        	     // false 생성된 객체가 해당타입아님
        	if(arr[i] instanceof Credit) {
        	String cardNumber = ((Credit)arr[i]).getCardNumber();
        	System.out.println("카드번호는.."+cardNumber);
        	} else if(arr[i] instanceof Pointpay) {
        		int point = ((Pointpay)arr[i]).getMyPoint();
        		System.out.println("포인트점수는"+point);
        	}
        	
        }
	}

}
