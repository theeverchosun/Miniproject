package Frun;


import FModel.View;

public class Run {

	public static void main(String[] args) {
		
		View manager = new View(10);


        manager.mainMenu();


        manager.printSpecialCareMembers();

	}

}
