package com.kh.game;

import java.util.Scanner;

public class ConsoleView {

	public static void main(String[] args) {
		GameState state = new GameState();

		System.out.println(" 콘솔 타자 게임 ");

		Thread t1 = new Thread(() -> {

			while (state.isGameRunning()) {

				try {

					Thread.sleep(1000);
					state.decreaseTime();
				} catch (InterruptedException e) {
					e.printStackTrace();
					break;
				}

			}

		});

		t1.start();

		Scanner sc = new Scanner(System.in);

		while (state.isGameRunning()) {

			String input = sc.nextLine();

			state.checkAnswer(input);

		}

		System.out.println(" * =========== GAME END ========== *");
		System.out.println(" 획득한 총 점수는 " + state.getScore() + "점 입니다.");
	}

}
