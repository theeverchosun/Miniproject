package com.kh.music.controller;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.kh.music.model.compare.AscTitle;
import com.kh.music.model.vo.Music;

public class MusicController {
	
	private List<Music> list = new ArrayList<>();
	

	
	public int addList(Music music) {
		list.add(music);
		
		return 1;
		
	}
	
	public int addAtZero(Music music) {
		list.add(0,music);
		return 1;
	}
	
	public List<Music> printAll() {
		return list;
	}
	
	public Music searchMusic(String title) {
		
		for(Music m : list) {
			if (m.getTitle().equals(title)) {
				return m;
			}
		}
		return null;
	}
	
	public Music removeMusic(String title) {
		
		for(int i=0; i<list.size(); i++) {
			if(list.get(i).getTitle().equals(title)) {
				return list.remove(i);
			}
		}
		return null;
		
	}
	
	public Music setMusic(String title, Music music) {
		
		for(int i=0; i< list.size(); i++) {
			
			if(list.get(i).getTitle().equals(title)) {
				Music m = list.remove(i);
				list.add(i, music);
				
				return m;
			}
		}
		return null;
	}
	
	public int ascTitle() {
		Collections.sort(list, new AscTitle());
		return 1;
	}
	
	public int descSinger() {
		Collections.sort(list);
		return 1;
	}
	
	/*
	 * 현재까지 등록된 전체 곡 목록을 파일에  저장합니다.
	 */
public int  fileSave() {
	//출력용 스트림
	try(BufferedWriter bw = new BufferedWriter(new FileWriter("musiclist.txt"))) 
}catch (IOException e) {
	e.printStackTrace();
	return 0;
}
}
