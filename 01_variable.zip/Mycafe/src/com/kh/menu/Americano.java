package com.kh.menu;

public class Americano extends Drink {

	public Americano(String name, int Price) {
		super(name, Price);
	}

	@Override
	public void order() {
		System.out.println("에스프레소샷을 추가합니다");
	}
}
	