package com.kh.ex2.model;

public interface CellPhone {
	
	public String charge();

}
