package com.kh;

public class C_StringBuilder {
	//java.lan.StringBuilder : 같은 메모리내의 값을 변경

	public static void main(String[] args) {
		//StringBuilder 객체 생성 => String 변수 필요
		
		String str = "summer";
		StringBuilder sb = new StringBuilder(str);
		
		System.out.println(sb);
		//toString 재정의되어있음(저장된값으로 리턴)
		
		int hash = System.identityHashCode(sb);
		System.out.println(hash);
		
		//값을 변경 추가: append()
		sb.append(" is hot");
		sb.append("  @@@@@");
		
		System.out.println(sb);
		int hash2 = System.identityHashCode(sb);
		System.out.println(hash2);
		

	}

}
