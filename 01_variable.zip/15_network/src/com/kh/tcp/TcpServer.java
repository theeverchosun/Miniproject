package com.kh.tcp;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
public class TcpServer {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		//[1] 포트 번호 지정
	    int port = 1024;
	    
	    //[2] 서버 소켓 객체 생성
	    try {
	    ServerSocket server = new ServerSocket(port);
	    System.out.println("클라이언트 요정 대기중.....");
	    Socket sock = server.accept();
	    BufferedReader br = new BufferedReader (
	    		new InputStreamReader(sock.getInputStream())
	    		);
	    		PrintWriter pw = new PrintWriter(sock.getOutputStream());
	    		while(true) {
	    			String message = br.readLine();
	    			System.out.println("클라이언트"+message);
	    			System.out.print("보낼 내용 : ");
	    			String sendMessage = sc.nextLine();
	    			
	    			pw.println(sendMessage);
	    			pw.flush();
	    			
	    		}
	    
	    } catch(IOException e) {
	    	e.printStackTrace();
	    }
	}

}
