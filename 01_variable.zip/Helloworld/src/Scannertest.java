// Scanner 등록 위치지정
import java.util.Scanner;

public class Scannertest {
	
	public static void main(String[] args) {
		//Scanner 사용 준비
		Scanner sc = new Scanner(System.in);
		//화면에 안내메세지 표시
		System.out.print("아무거나 입력: ");
		
	    //키보드로 입력받기
		String data = sc.nextLine();
		
		//입력받은값 출력
		
		System.out.println(data);
		
		//스캐너 사용 완료 선언
		sc.close();
		
	}

}
