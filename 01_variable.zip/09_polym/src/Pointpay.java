

public class Pointpay extends PaymentMethod {
	
	private int myPoint;
	
	public Pointpay() {
		
	}
	public Pointpay(String payName, int payAmount, int myPoint) {
		super(payName, payAmount);
		this.myPoint = myPoint;
	}

	public int getMyPoint() {
		return myPoint;
	}
	public void setMyPoint(int myPoint) {
		this.myPoint = myPoint;
	}

	
	public void processPay() {
		System.out.println("====포인트 결제 방식====");
		System.out.println("결제 금액 :" + getPayAmount());
		System.out.println("내 포인트 잔액 :"+ myPoint);
		System.out.println(
				(getPayAmount() < myPoint)? "결제 성공" : "결제실패(잔액 부족)"
				);
		
	}
}
