package com.kh.pos.run;

import com.kh.pos.view.Posmenu;

public class Run {

	public static void main(String[] args) {


		Posmenu posMenu = new Posmenu();
		posMenu.mainMenu(); 
		
		

	}

}
