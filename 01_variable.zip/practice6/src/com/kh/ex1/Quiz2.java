package com.kh.ex1;

import java.util.Scanner;


public class Quiz2 {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		String[] arr ={"사과","딸기","바나나","키위","복수아"};
		
		System.out.print("찾을과일을찾으세요 ");
		String fname =sc.nextLine();
		
		int findex = -1;
		
		for(int i =0; i< arr.length; i++) {
			boolean isEquals = arr[i].equals(fname);
			
			if(isEquals) {
				findex = i;
				break;
			}}
			
			if(findex>-1) {
				System.out.println(fname + "은배열의"+ findex+"번의 인덱스에 있습니다");
			} else {
				System.out.println("찾는 과일이없습니다");
			}
		}
		
		
	}


