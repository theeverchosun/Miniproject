package com.kh.ex2;

public class Circle implements Shape {
	
	
	double Cr;
	
	public Circle(double Cr) {
		
		this.Cr = Cr;
	}

	@Override
	public double caculateArea() {
		// TODO Auto-generated method stub
		return Math.PI*Cr*Cr;
	}

}
