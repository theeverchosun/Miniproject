package com.kh.ex1;

//접근제한 interface 인터페이스명{}
public interface Animal {	
	//상수 필드와 추상메소드로 구성
	//움직인다
	//먹는다
	//소리를 낸다
	public abstract void move();
			
	public void eat();
	
	void makesound();
	
	//=. 추상메소드는 몸체가 없는 메소드다

}
