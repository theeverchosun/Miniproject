package com.kh.ex1;

//thread 생성 방법 Runnable 인터페이스 구현

public class task1 implements Runnable {

	@Override
	public void run() {
		//스레드 실행 내용
		String threadName = Thread.currentThread().getName();
		System.out.println(threadName+"실행중!");
		
	}
	
	

}
