package com.kh.ex2.controller;

import java.util.Scanner;

public class StudyCafeView {
	
	private
	
	

}
