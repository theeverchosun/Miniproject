package com.kh.ex2.model;

public class GalaxyNote9 extends SmartPhone implements Phone, Camera, CellPhone, TouchDisplay, NotePen {
	
	public GalaxyNote9() {
		
		setMaker("삼성");
		
		
	}

	@Override
	public boolean bluetoothPen() {
		// TODO Auto-generated method stub
		return PEN_BUTTON;
	}

	@Override
	public String charge() {
		// TODO Auto-generated method stub
		return "고속충전, 고속무선충적";
	}

	@Override
	public String picture() {
		// TODO Auto-generated method stub
		return "1200만 듀얼카메라";
	}

	@Override
	public String makeCall() {
		// TODO Auto-generated method stub
		return "번호를 누르고  통화버튼을 누름";
	}

	@Override
	public String takeCall() {
		// TODO Auto-generated method stub
		return "수신 버튼을 누름";
	}

	@Override
	public String touch() {
		// TODO Auto-generated method stub
		return "정전식, 와콤펜 지원";
	}

	@Override
	public String printlnformation() {
		// TODO Auto-generated method stub
		return String.format("갤럭시 노트9은 %s에서 만들어졌고  제원은 다음과 같다.\n"
				+"%s\n"
				+"%s\n"
				+"%s\n"
				+"%s\n"
				+"%s\n"
				+"블루투스 펜 탑재 여주 : %b"
				,getMaker(),makeCall(),takeCall(),picture(),charge(),touch(), bluetoothPen());
	}


	

}
